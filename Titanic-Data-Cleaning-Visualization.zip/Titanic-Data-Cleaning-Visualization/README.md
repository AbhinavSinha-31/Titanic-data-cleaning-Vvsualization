# Titanic Data Cleaning & Visualization

## Project Overview
This project demonstrates data cleaning, preprocessing, and visualization using the Titanic dataset.

## Files
- `Task1_Data_Cleaning_Visualization.ipynb` – Jupyter notebook version
- `task1_data_cleaning_visualization.py` – Python script version
- `titanic_cleaned.csv` – Cleaned dataset
- `dashboard.png` – Dashboard visualization
- `cleaning_summary.png` – Data cleaning summary

## Data Cleaning Steps
- Handled missing values
- Removed or corrected inconsistent data
- Prepared data for analysis and visualization

## Visualizations
The project includes graphical summaries and dashboard-style visualizations to understand passenger demographics and survival patterns.

## How to Run
1. Install Python and required libraries.
2. Open the notebook or run the Python script.
3. Review generated visualizations and cleaned dataset.

## Skills Demonstrated
- Python
- Pandas
- Data Cleaning
- Data Visualization
- Exploratory Data Analysis (EDA)

## Author
Avi
