# ============================================================
# TASK 1: Data Cleaning & Visualization Project
# Dataset: Titanic - Machine Learning from Disaster
# Author: Abhinav Sinha
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# ── Style ────────────────────────────────────────────────────
plt.rcParams['figure.facecolor'] = '#0f1117'
plt.rcParams['axes.facecolor']   = '#1a1d27'
plt.rcParams['axes.edgecolor']   = '#444'
plt.rcParams['text.color']       = 'white'
plt.rcParams['axes.labelcolor']  = 'white'
plt.rcParams['xtick.color']      = 'white'
plt.rcParams['ytick.color']      = 'white'
plt.rcParams['grid.color']       = '#2a2d3a'
plt.rcParams['grid.linestyle']   = '--'
plt.rcParams['grid.alpha']       = 0.5
ACCENT = '#4f8ef7'
ROSE   = '#e05c7a'
GREEN  = '#3ecf8e'
YELLOW = '#f5a623'

# ── 1. LOAD DATA ─────────────────────────────────────────────
print("=" * 55)
print("  TITANIC DATA CLEANING & VISUALIZATION")
print("=" * 55)

df_raw = pd.read_csv('titanic.csv')
print(f"\n[1] Raw dataset loaded: {df_raw.shape[0]} rows × {df_raw.shape[1]} columns")
print(f"    Columns: {df_raw.columns.tolist()}")

# ── 2. PRE-CLEANING REPORT ───────────────────────────────────
print("\n[2] Missing Values (before cleaning):")
missing = df_raw.isnull().sum()
missing_pct = (missing / len(df_raw) * 100).round(2)
miss_df = pd.DataFrame({'Missing': missing, 'Pct (%)': missing_pct})
print(miss_df[miss_df['Missing'] > 0].to_string())

dups = df_raw.duplicated().sum()
print(f"\n    Duplicate rows: {dups}")

# ── 3. DATA CLEANING ─────────────────────────────────────────
print("\n[3] Cleaning steps:")
df = df_raw.copy()

# 3a. Drop Cabin (>77% missing) and irrelevant cols
df.drop(columns=['Cabin', 'Ticket', 'Name', 'PassengerId'], inplace=True)
print("    ✔ Dropped Cabin (77% missing), Ticket, Name, PassengerId")

# 3b. Fill Age with median grouped by Pclass & Sex
df['Age'] = df.groupby(['Pclass', 'Sex'])['Age'].transform(
    lambda x: x.fillna(x.median()))
print(f"    ✔ Imputed Age with group median (Pclass × Sex)")

# 3c. Fill Embarked with mode
df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)
print(f"    ✔ Imputed Embarked with mode: '{df_raw['Embarked'].mode()[0]}'")

# 3d. Remove duplicates
before = len(df)
df.drop_duplicates(inplace=True)
print(f"    ✔ Dropped {before - len(df)} duplicate rows")

# 3e. Feature engineering
df['FamilySize'] = df['SibSp'] + df['Parch'] + 1
df['IsAlone']    = (df['FamilySize'] == 1).astype(int)
df['AgeGroup']   = pd.cut(df['Age'],
    bins=[0,12,18,35,60,100],
    labels=['Child','Teen','Adult','Middle-Age','Senior'])
print("    ✔ Engineered: FamilySize, IsAlone, AgeGroup")

print(f"\n    Clean dataset: {df.shape[0]} rows × {df.shape[1]} columns")
print(f"    Remaining nulls: {df.isnull().sum().sum()}")

# ── 4. DESCRIPTIVE STATS ─────────────────────────────────────
print("\n[4] Descriptive Statistics:")
print(df.describe(include='all').to_string())

# ═══════════════════════════════════════════════════════════════
#  DASHBOARD — Figure 1 (3 × 3 grid)
# ═══════════════════════════════════════════════════════════════
fig, axes = plt.subplots(3, 3, figsize=(18, 14))
fig.patch.set_facecolor('#0f1117')
fig.suptitle('Titanic — Data Cleaning & Visualization Dashboard\nAbhinav Sinha',
             fontsize=16, fontweight='bold', color='white', y=0.98)

# ── Plot 1: Missing Values Heatmap (before) ──────────────────
ax = axes[0, 0]
miss_cols = miss_df[miss_df['Missing'] > 0]
colors = [ROSE if p > 50 else YELLOW if p > 10 else ACCENT
          for p in miss_cols['Pct (%)']]
bars = ax.barh(miss_cols.index, miss_cols['Pct (%)'], color=colors)
ax.set_title('Missing Values (Before Cleaning)', fontsize=11, color='white', pad=8)
ax.set_xlabel('Missing %', color='white')
for bar, val in zip(bars, miss_cols['Pct (%)']):
    ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2,
            f'{val}%', va='center', color='white', fontsize=9)
ax.set_xlim(0, 110)
ax.grid(axis='x')

# ── Plot 2: Survival Count ────────────────────────────────────
ax = axes[0, 1]
surv_counts = df['Survived'].value_counts()
bars = ax.bar(['Did Not Survive', 'Survived'], surv_counts.values,
              color=[ROSE, GREEN], edgecolor='#0f1117', linewidth=1.5, width=0.5)
ax.set_title('Survival Count', fontsize=11, color='white', pad=8)
ax.set_ylabel('Passengers', color='white')
for bar in bars:
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
            str(bar.get_height()), ha='center', color='white', fontsize=11, fontweight='bold')
ax.grid(axis='y')

# ── Plot 3: Survival Rate by Gender ──────────────────────────
ax = axes[0, 2]
gender_surv = df.groupby('Sex')['Survived'].mean() * 100
bars = ax.bar(gender_surv.index, gender_surv.values,
              color=[ROSE, ACCENT], edgecolor='#0f1117', linewidth=1.5, width=0.4)
ax.set_title('Survival Rate by Gender', fontsize=11, color='white', pad=8)
ax.set_ylabel('Survival Rate (%)', color='white')
ax.set_ylim(0, 100)
for bar, val in zip(bars, gender_surv.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1.5,
            f'{val:.1f}%', ha='center', color='white', fontsize=11, fontweight='bold')
ax.grid(axis='y')

# ── Plot 4: Age Distribution ──────────────────────────────────
ax = axes[1, 0]
ax.hist(df_raw['Age'].dropna(), bins=30, color=ROSE, alpha=0.6,
        edgecolor='#0f1117', label='Before')
ax.hist(df['Age'], bins=30, color=ACCENT, alpha=0.6,
        edgecolor='#0f1117', label='After Imputation')
ax.set_title('Age Distribution (Before vs After Imputation)', fontsize=11, color='white', pad=8)
ax.set_xlabel('Age', color='white')
ax.set_ylabel('Count', color='white')
ax.legend(facecolor='#1a1d27', labelcolor='white')
ax.grid(axis='y')

# ── Plot 5: Survival by Passenger Class ──────────────────────
ax = axes[1, 1]
pclass_surv = df.groupby('Pclass')['Survived'].mean() * 100
bars = ax.bar([f'Class {c}' for c in pclass_surv.index],
              pclass_surv.values,
              color=[GREEN, YELLOW, ROSE], edgecolor='#0f1117', linewidth=1.5, width=0.5)
ax.set_title('Survival Rate by Passenger Class', fontsize=11, color='white', pad=8)
ax.set_ylabel('Survival Rate (%)', color='white')
ax.set_ylim(0, 80)
for bar, val in zip(bars, pclass_surv.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
            f'{val:.1f}%', ha='center', color='white', fontsize=11, fontweight='bold')
ax.grid(axis='y')

# ── Plot 6: Fare Distribution by Class ───────────────────────
ax = axes[1, 2]
for i, (pclass, color) in enumerate(zip([1, 2, 3], [GREEN, YELLOW, ROSE])):
    data = df[df['Pclass'] == pclass]['Fare']
    ax.hist(data, bins=25, color=color, alpha=0.7,
            edgecolor='#0f1117', label=f'Class {pclass}')
ax.set_title('Fare Distribution by Passenger Class', fontsize=11, color='white', pad=8)
ax.set_xlabel('Fare (£)', color='white')
ax.set_ylabel('Count', color='white')
ax.legend(facecolor='#1a1d27', labelcolor='white')
ax.set_xlim(0, 300)
ax.grid(axis='y')

# ── Plot 7: Correlation Heatmap ───────────────────────────────
ax = axes[2, 0]
num_cols = ['Survived', 'Pclass', 'Age', 'SibSp', 'Parch', 'Fare', 'FamilySize', 'IsAlone']
corr = df[num_cols].corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, ax=ax, mask=mask, annot=True, fmt='.2f', cmap='coolwarm',
            linewidths=0.5, linecolor='#0f1117',
            annot_kws={'size': 8, 'color': 'white'},
            cbar_kws={'shrink': 0.8})
ax.set_title('Correlation Heatmap', fontsize=11, color='white', pad=8)
ax.tick_params(colors='white', labelsize=8)

# ── Plot 8: Survival by Age Group ────────────────────────────
ax = axes[2, 1]
age_surv = df.groupby('AgeGroup', observed=True)['Survived'].mean() * 100
colors_age = [GREEN if v > 40 else ROSE for v in age_surv.values]
bars = ax.bar(age_surv.index.astype(str), age_surv.values,
              color=colors_age, edgecolor='#0f1117', linewidth=1.5, width=0.5)
ax.set_title('Survival Rate by Age Group', fontsize=11, color='white', pad=8)
ax.set_ylabel('Survival Rate (%)', color='white')
ax.set_ylim(0, 70)
for bar, val in zip(bars, age_surv.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
            f'{val:.1f}%', ha='center', color='white', fontsize=9, fontweight='bold')
ax.grid(axis='y')

# ── Plot 9: Family Size vs Survival ──────────────────────────
ax = axes[2, 2]
fam_surv = df.groupby('FamilySize')['Survived'].mean() * 100
ax.plot(fam_surv.index, fam_surv.values,
        color=ACCENT, marker='o', markersize=8,
        markerfacecolor=YELLOW, linewidth=2.5)
ax.fill_between(fam_surv.index, fam_surv.values, alpha=0.15, color=ACCENT)
ax.set_title('Survival Rate by Family Size', fontsize=11, color='white', pad=8)
ax.set_xlabel('Family Size', color='white')
ax.set_ylabel('Survival Rate (%)', color='white')
ax.set_ylim(0, 80)
ax.grid()

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig('/home/claude/dashboard.png', dpi=150, bbox_inches='tight',
            facecolor='#0f1117')
plt.close()
print("\n[5] Dashboard saved: dashboard.png")

# ═══════════════════════════════════════════════════════════════
#  FIGURE 2 — Cleaned Data Summary Card
# ═══════════════════════════════════════════════════════════════
fig2, ax = plt.subplots(figsize=(12, 5))
fig2.patch.set_facecolor('#0f1117')
ax.set_facecolor('#0f1117')
ax.axis('off')

summary_data = [
    ['Metric', 'Before Cleaning', 'After Cleaning'],
    ['Total Rows', '891', str(len(df))],
    ['Total Columns', '12', str(len(df.columns))],
    ['Missing Values', '866', '0'],
    ['Duplicate Rows', str(dups), '0'],
    ['Age Nulls', '177 (19.9%)', '0 (0%)'],
    ['Cabin Nulls', '687 (77.1%)', 'Dropped'],
    ['Embarked Nulls', '2 (0.2%)', '0 (0%)'],
    ['New Features', '—', 'FamilySize, IsAlone, AgeGroup'],
]

table = ax.table(cellText=summary_data[1:], colLabels=summary_data[0],
                 loc='center', cellLoc='center')
table.auto_set_font_size(False)
table.set_fontsize(12)
table.scale(1.4, 2.2)

for (row, col), cell in table.get_celld().items():
    cell.set_edgecolor('#333')
    if row == 0:
        cell.set_facecolor('#4f8ef7')
        cell.set_text_props(color='white', fontweight='bold')
    elif row % 2 == 0:
        cell.set_facecolor('#1e2130')
        cell.set_text_props(color='white')
    else:
        cell.set_facecolor('#252836')
        cell.set_text_props(color='#ddd')

ax.set_title('Data Cleaning Summary — Titanic Dataset\nAbhinav Sinha',
             fontsize=14, fontweight='bold', color='white', pad=20)
plt.tight_layout()
plt.savefig('/home/claude/cleaning_summary.png', dpi=150, bbox_inches='tight',
            facecolor='#0f1117')
plt.close()
print("[6] Summary table saved: cleaning_summary.png")

# ── Save cleaned CSV ─────────────────────────────────────────
df.to_csv('/home/claude/titanic_cleaned.csv', index=False)
print("[7] Clean dataset saved: titanic_cleaned.csv")
print("\n✅ All outputs ready!")
